# kubectx

> Switch between clusters and namespaces in kubectl

- List available contexts

`kubectx`

- Switch to a cluster

`kubectx <NAME>`

