# pushd

> Place a directory on a stack so it can be accessed later.
> See also `popd` to switch back to original directory.

- Switch to directory and push it on the stack:

`pushd {{directory}}`
