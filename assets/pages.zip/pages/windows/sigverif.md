# sigverif

> A GUI signature verification tool for checking system files.

- Open the File Signature Verification interface:

`sigverif`
