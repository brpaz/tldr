# sensible-browser

> Open the default browser.

- Open a new window of the default browser:

`sensible-browser`

- Open a url in the default browser:

`sensible-browser {{url}}`
