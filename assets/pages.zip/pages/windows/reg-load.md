# reg load

> Load saved sub keys into a different sub key in the registry.
> This is intended for troubleshooting and temporary keys.

- Load a backup file into the specified key:

`reg load {{key_name}} {{path/to/file}}`
