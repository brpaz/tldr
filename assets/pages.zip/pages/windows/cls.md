# cls

> Clears the screen.

- Clear the screen:

`cls`
