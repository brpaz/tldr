# gcloud

> Tool for managing Google Cloud

- Initializes the SDK:

`gcloud init`

- View information your Cloud SDK installation and the active SDK configuration:

`gcloud info`
