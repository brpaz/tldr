# localtunnel

> Exposes your localhost to the world for easy testing and sharing.

- Open localtunnel on port:

`lt --port 8000`

- Run localtunnel on subdomain:

`lt --subdomain example.com`

- Proxy to hostname rather than localhost:

`lt --local-host myhost`
