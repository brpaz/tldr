# ntfsfix

> Fix common problems on an NTFS partition.

- Fix a given NTFS partition:

`sudo ntfsfix {{/dev/sdb2}}`
