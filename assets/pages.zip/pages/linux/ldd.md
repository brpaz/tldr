# ldd

> Display shared library dependencies.

- Display shared library dependencies of a binary:

`ldd {{path/to/binary}}`

- Display unused direct dependencies:

`ldd -u {{path/to/binary}}`
