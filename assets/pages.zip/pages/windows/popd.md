# popd

> Changes the current directory to the directory stored by the `pushd` command.

- Switch to directory at the top of the stack:

`popd`
