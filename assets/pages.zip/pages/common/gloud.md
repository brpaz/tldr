# gcloud

> Tool for managing Google Cloud.

- Initialize the SDK:

`gcloud init`

- View information your Cloud SDK installation and the active SDK configuration:

`gcloud info`
